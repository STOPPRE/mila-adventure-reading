// Mila — a stylized SVG puppy that gains outfit items as Carolina progresses.
// Based on Mila being a black/white bicolor Retriever Mix puppy.

export default function Mila({ items = [], mood = 'happy', size = 180 }) {
  // mood: 'happy' (default tail wag), 'thinking' (still), 'celebrating' (bigger smile)
  return (
    <svg
      viewBox="0 0 200 200"
      width={size}
      height={size}
      style={{ display: 'block' }}
      aria-label="Mila the puppy"
    >
      {/* Tail */}
      <g className={`mila-tail mila-tail-${mood}`}>
        <path
          d="M 158 110 Q 178 95 175 75"
          fill="none"
          stroke="#2C2C2C"
          strokeWidth="9"
          strokeLinecap="round"
        />
        <path
          d="M 158 110 Q 178 95 175 75"
          fill="none"
          stroke="#F5F5F5"
          strokeWidth="4"
          strokeLinecap="round"
        />
      </g>

      {/* Back leg right */}
      <ellipse cx="135" cy="155" rx="14" ry="22" fill="#2C2C2C" />
      <ellipse cx="135" cy="170" rx="14" ry="10" fill="#F5F5F5" />

      {/* Back leg left */}
      <ellipse cx="65" cy="155" rx="14" ry="22" fill="#2C2C2C" />
      <ellipse cx="65" cy="170" rx="14" ry="10" fill="#F5F5F5" />

      {/* Body — black with white belly */}
      <ellipse cx="100" cy="125" rx="55" ry="38" fill="#2C2C2C" />
      <ellipse cx="100" cy="138" rx="38" ry="20" fill="#F5F5F5" />

      {/* Backpack (if worn) */}
      {items.includes('backpack') && (
        <g>
          <rect x="80" y="92" width="40" height="32" rx="6" fill="#B8724C" stroke="#6F3F25" strokeWidth="2" />
          <rect x="92" y="100" width="16" height="8" rx="2" fill="#6F3F25" />
          <line x1="78" y1="98" x2="65" y2="110" stroke="#6F3F25" strokeWidth="3" strokeLinecap="round" />
          <line x1="122" y1="98" x2="135" y2="110" stroke="#6F3F25" strokeWidth="3" strokeLinecap="round" />
        </g>
      )}

      {/* Front legs */}
      <ellipse cx="120" cy="160" rx="11" ry="20" fill="#2C2C2C" />
      <ellipse cx="120" cy="173" rx="11" ry="9" fill="#F5F5F5" />
      <ellipse cx="80" cy="160" rx="11" ry="20" fill="#2C2C2C" />
      <ellipse cx="80" cy="173" rx="11" ry="9" fill="#F5F5F5" />

      {/* Head */}
      <ellipse cx="100" cy="78" rx="42" ry="38" fill="#2C2C2C" />
      {/* White muzzle stripe */}
      <ellipse cx="100" cy="95" rx="20" ry="22" fill="#F5F5F5" />
      {/* White forehead blaze */}
      <path d="M 90 50 Q 100 75 110 50 L 105 42 Q 100 38 95 42 Z" fill="#F5F5F5" />

      {/* Ears */}
      <ellipse cx="65" cy="55" rx="14" ry="22" fill="#1A1A1A" transform="rotate(-20 65 55)" />
      <ellipse cx="135" cy="55" rx="14" ry="22" fill="#1A1A1A" transform="rotate(20 135 55)" />

      {/* Hat (if worn) */}
      {items.includes('hat') && (
        <g>
          <ellipse cx="100" cy="40" rx="32" ry="6" fill="#A28043" />
          <path d="M 75 40 Q 100 10 125 40 Z" fill="#A28043" stroke="#7A5F2F" strokeWidth="1.5" />
          <rect x="78" y="38" width="44" height="4" fill="#7A5F2F" />
        </g>
      )}

      {/* Eyes */}
      <ellipse cx="86" cy="72" rx="4" ry="5" fill="#FAF6F0" />
      <ellipse cx="114" cy="72" rx="4" ry="5" fill="#FAF6F0" />
      <circle cx="86" cy="73" r="2.5" fill="#1A1A1A" />
      <circle cx="114" cy="73" r="2.5" fill="#1A1A1A" />
      <circle cx="87" cy="71.5" r="0.8" fill="#FFFFFF" />
      <circle cx="115" cy="71.5" r="0.8" fill="#FFFFFF" />

      {/* Nose */}
      <ellipse cx="100" cy="88" rx="5" ry="4" fill="#1A1A1A" />

      {/* Mouth */}
      {mood === 'celebrating' ? (
        <path d="M 90 100 Q 100 112 110 100" stroke="#1A1A1A" strokeWidth="2" fill="#A63D40" strokeLinecap="round" />
      ) : mood === 'thinking' ? (
        <path d="M 92 100 Q 100 102 108 100" stroke="#1A1A1A" strokeWidth="2" fill="none" strokeLinecap="round" />
      ) : (
        <path d="M 92 99 Q 96 105 100 102 Q 104 105 108 99" stroke="#1A1A1A" strokeWidth="2" fill="none" strokeLinecap="round" />
      )}

      {/* Tongue (happy only) */}
      {mood === 'happy' && (
        <ellipse cx="100" cy="106" rx="4" ry="3" fill="#E07B8E" />
      )}

      {/* Collar (if worn) */}
      {items.includes('collar') && (
        <ellipse cx="100" cy="113" rx="32" ry="6" fill="#A28043" stroke="#7A5F2F" strokeWidth="1.5" />
      )}

      {/* Bandana (if worn) — over collar */}
      {items.includes('bandana') && (
        <g>
          <path d="M 68 113 L 132 113 L 138 125 L 100 132 L 62 125 Z" fill="#A63D40" stroke="#6B2729" strokeWidth="1.5" />
          <circle cx="80" cy="120" r="2" fill="#FAF6F0" />
          <circle cx="100" cy="124" r="2" fill="#FAF6F0" />
          <circle cx="120" cy="120" r="2" fill="#FAF6F0" />
        </g>
      )}

      {/* Medal (if won) */}
      {items.includes('medal') && (
        <g>
          <line x1="92" y1="115" x2="100" y2="142" stroke="#A28043" strokeWidth="2" />
          <line x1="108" y1="115" x2="100" y2="142" stroke="#A28043" strokeWidth="2" />
          <circle cx="100" cy="148" r="11" fill="#C4A456" stroke="#7A5F2F" strokeWidth="2" />
          <text x="100" y="153" textAnchor="middle" fontSize="14" fill="#7A5F2F" fontWeight="bold">★</text>
        </g>
      )}

      <style>{`
        .mila-tail-happy { transform-origin: 158px 110px; animation: wag 0.6s ease-in-out infinite; }
        .mila-tail-celebrating { transform-origin: 158px 110px; animation: wag 0.3s ease-in-out infinite; }
        .mila-tail-thinking { transform-origin: 158px 110px; }
        @keyframes wag {
          0%, 100% { transform: rotate(-10deg); }
          50% { transform: rotate(15deg); }
        }
      `}</style>
    </svg>
  );
}
