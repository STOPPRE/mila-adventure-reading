import { useState, useEffect, useMemo } from 'react';
import Mila from './Mila';
import {
  clozeSentences, cognatePairs, syllableWords, walkStops,
  currentOutfit, pick, shuffle,
} from './gameData';

// ===================== UTILITIES =====================

function useSparkle(trigger) {
  const [sparkles, setSparkles] = useState([]);
  useEffect(() => {
    if (trigger > 0) {
      const newSparkles = Array.from({ length: 8 }, (_, i) => ({
        id: trigger * 100 + i,
        x: 50 + (Math.random() - 0.5) * 60,
        y: 50 + (Math.random() - 0.5) * 60,
        delay: Math.random() * 0.3,
      }));
      setSparkles(newSparkles);
      const t = setTimeout(() => setSparkles([]), 1200);
      return () => clearTimeout(t);
    }
  }, [trigger]);
  return sparkles;
}

// ===================== START SCREEN =====================

function StartScreen({ onStart, onContinue, hasProgress }) {
  return (
    <div className="screen start-screen">
      <div className="start-clouds">
        <div className="cloud cloud-1">☁️</div>
        <div className="cloud cloud-2">☁️</div>
        <div className="cloud cloud-3">☁️</div>
      </div>
      <div className="start-content">
        <div className="start-mila">
          <Mila size={220} mood="happy" />
        </div>
        <h1 className="game-title">Mila's Adventure Park</h1>
        <p className="game-subtitle">
          Help Mila walk through the park! Solve puzzles in Spanish and English to earn treats and outfits.
        </p>
        <div className="start-buttons">
          {hasProgress && (
            <button className="btn btn-primary" onClick={onContinue}>
              Continue Walk →
            </button>
          )}
          <button className={`btn ${hasProgress ? 'btn-secondary' : 'btn-primary'}`} onClick={onStart}>
            {hasProgress ? 'Start Over' : "Let's Go! 🐾"}
          </button>
        </div>
        <div className="start-features">
          <div className="feature">
            <div className="feature-emoji">📖</div>
            <div className="feature-text">Spanish reading</div>
          </div>
          <div className="feature">
            <div className="feature-emoji">🔤</div>
            <div className="feature-text">Word matching</div>
          </div>
          <div className="feature">
            <div className="feature-emoji">🪨</div>
            <div className="feature-text">Syllable hops</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ===================== TRAIL MAP =====================

function TrailMap({ currentStop, onContinue, treats, outfit }) {
  const upcoming = walkStops[currentStop];
  return (
    <div className="screen trail-screen">
      <header className="game-header">
        <div className="header-stats">
          <div className="stat">
            <div className="stat-emoji">🦴</div>
            <div className="stat-num">{treats}</div>
          </div>
          <div className="stat">
            <div className="stat-emoji">🐾</div>
            <div className="stat-num">{currentStop}/{walkStops.length}</div>
          </div>
        </div>
        <div className="outfit-badge">{outfit.name}</div>
      </header>

      <div className="trail-container">
        <h2 className="trail-title">The Trail So Far</h2>
        <div className="trail-path">
          {walkStops.map((stop, i) => {
            const done = i < currentStop;
            const current = i === currentStop;
            return (
              <div
                key={stop.num}
                className={`trail-stop ${done ? 'done' : ''} ${current ? 'current' : ''}`}
              >
                <div className="stop-dot">
                  <span className="stop-emoji">{done ? '✅' : current ? '🐾' : stop.emoji}</span>
                </div>
                <div className="stop-label">{stop.name}</div>
              </div>
            );
          })}
        </div>

        {upcoming && (
          <div className="next-card">
            <div className="next-eyebrow">Next Stop</div>
            <div className="next-name">
              <span className="next-emoji">{upcoming.emoji}</span> {upcoming.name}
            </div>
            <div className="next-type">
              {upcoming.mode === 'cloze' && '📖 Spanish reading challenge'}
              {upcoming.mode === 'cognate' && '🔤 Spanish-English word match'}
              {upcoming.mode === 'syllable' && '🪨 Syllable hopping'}
              {upcoming.mode === 'treat' && '🦴 Treat stop! Free bonus'}
              {upcoming.mode === 'finish' && '🏡 The finish line!'}
            </div>
            <button className="btn btn-primary btn-large" onClick={onContinue}>
              Keep Walking →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ===================== CLOZE MODE (Spanish MAZE) =====================

function ClozeChallenge({ onComplete, onSkip }) {
  const [item] = useState(() => pick(clozeSentences));
  const [order] = useState(() => shuffle(item.choices));
  const [selected, setSelected] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const [showHint, setShowHint] = useState(false);

  const handleSelect = (choice) => {
    if (selected !== null) return;
    setSelected(choice);
    const correct = choice === item.correct;
    setTimeout(() => {
      setShowResult(true);
      setTimeout(() => onComplete(correct), 1800);
    }, 400);
  };

  const parts = item.sentence.split('___');

  return (
    <div className="screen challenge-screen cloze-screen">
      <div className="challenge-header">
        <button className="back-btn" onClick={onSkip}>← Back to trail</button>
        <div className="challenge-badge">📖 Reading in Spanish</div>
      </div>

      <div className="challenge-body">
        <div className="cloze-mila">
          <Mila size={120} mood={showResult && selected === item.correct ? 'celebrating' : 'thinking'} />
        </div>
        <div className="cloze-prompt">
          Pick the word that makes the sentence make sense:
        </div>
        <div className="cloze-sentence">
          {parts[0]}
          <span className={`cloze-blank ${selected ? 'filled' : ''} ${showResult ? (selected === item.correct ? 'correct' : 'wrong') : ''}`}>
            {selected || '_____'}
          </span>
          {parts[1]}
        </div>

        <div className="cloze-choices">
          {order.map((choice) => {
            const isSelected = selected === choice;
            const isCorrect = showResult && choice === item.correct;
            const isWrong = showResult && isSelected && choice !== item.correct;
            return (
              <button
                key={choice}
                className={`choice-btn ${isSelected ? 'selected' : ''} ${isCorrect ? 'correct' : ''} ${isWrong ? 'wrong' : ''}`}
                onClick={() => handleSelect(choice)}
                disabled={selected !== null}
              >
                {choice}
              </button>
            );
          })}
        </div>

        {!selected && !showHint && (
          <button className="hint-btn" onClick={() => setShowHint(true)}>
            💡 Need a hint?
          </button>
        )}
        {showHint && !selected && (
          <div className="hint-box">{item.hint}</div>
        )}

        {showResult && (
          <div className={`result-banner ${selected === item.correct ? 'result-good' : 'result-try'}`}>
            {selected === item.correct ? '¡Excelente! 🎉' : `The answer was "${item.correct}". You'll get the next one!`}
          </div>
        )}
      </div>
    </div>
  );
}

// ===================== COGNATE MODE =====================

function CognateChallenge({ onComplete, onSkip }) {
  const [item] = useState(() => pick(cognatePairs));
  const [order] = useState(() => shuffle([item.correct, ...item.distractors]));
  const [selected, setSelected] = useState(null);
  const [showResult, setShowResult] = useState(false);

  const handleSelect = (choice) => {
    if (selected !== null) return;
    setSelected(choice);
    const correct = choice === item.correct;
    setTimeout(() => {
      setShowResult(true);
      setTimeout(() => onComplete(correct), 1800);
    }, 400);
  };

  return (
    <div className="screen challenge-screen cognate-screen">
      <div className="challenge-header">
        <button className="back-btn" onClick={onSkip}>← Back to trail</button>
        <div className="challenge-badge">🔤 Word twins (cognates)</div>
      </div>

      <div className="challenge-body">
        <div className="cognate-mila">
          <Mila size={110} mood={showResult && selected === item.correct ? 'celebrating' : 'thinking'} />
        </div>
        <div className="cognate-prompt">
          What's the English word that means the same thing?
        </div>
        <div className="cognate-word-card">
          <div className="cognate-flag">🇪🇸 Spanish</div>
          <div className="cognate-word">{item.spanish}</div>
        </div>

        <div className="cognate-arrow">↓</div>

        <div className="cognate-choices">
          {order.map((choice) => {
            const isSelected = selected === choice;
            const isCorrect = showResult && choice === item.correct;
            const isWrong = showResult && isSelected && choice !== item.correct;
            return (
              <button
                key={choice}
                className={`choice-btn cognate-choice ${isSelected ? 'selected' : ''} ${isCorrect ? 'correct' : ''} ${isWrong ? 'wrong' : ''}`}
                onClick={() => handleSelect(choice)}
                disabled={selected !== null}
              >
                <span className="choice-flag">🇺🇸</span> {choice}
              </button>
            );
          })}
        </div>

        {showResult && (
          <div className={`result-banner ${selected === item.correct ? 'result-good' : 'result-try'}`}>
            {selected === item.correct
              ? `Right! "${item.spanish}" and "${item.correct}" are word twins!`
              : `"${item.spanish}" is "${item.correct}" in English. They're word twins!`}
          </div>
        )}
      </div>
    </div>
  );
}

// ===================== SYLLABLE STONES MODE =====================

function SyllableChallenge({ onComplete, onSkip }) {
  const [item] = useState(() => pick(syllableWords));
  // Build letter array with split-points between letters
  const letters = item.word.split('');
  // Correct split positions (after which letter index)
  const correctSplits = useMemo(() => {
    const splits = [];
    let pos = 0;
    for (let i = 0; i < item.syllables.length - 1; i++) {
      pos += item.syllables[i].length;
      splits.push(pos);
    }
    return splits;
  }, [item]);

  const [userSplits, setUserSplits] = useState([]);
  const [showResult, setShowResult] = useState(false);
  const [resultGood, setResultGood] = useState(false);

  const toggleSplit = (pos) => {
    if (showResult) return;
    setUserSplits((s) =>
      s.includes(pos) ? s.filter((x) => x !== pos) : [...s, pos].sort((a, b) => a - b)
    );
  };

  const checkAnswer = () => {
    const sorted = [...userSplits].sort((a, b) => a - b);
    const matches =
      sorted.length === correctSplits.length &&
      sorted.every((v, i) => v === correctSplits[i]);
    setResultGood(matches);
    setShowResult(true);
    setTimeout(() => onComplete(matches), 2200);
  };

  const numTargets = item.syllables.length;

  return (
    <div className="screen challenge-screen syllable-screen">
      <div className="challenge-header">
        <button className="back-btn" onClick={onSkip}>← Back to trail</button>
        <div className="challenge-badge">🪨 Stepping stones</div>
      </div>

      <div className="challenge-body">
        <div className="syllable-mila">
          <Mila size={110} mood={showResult && resultGood ? 'celebrating' : 'thinking'} />
        </div>
        <div className="syllable-prompt">
          Tap between letters to break this word into <strong>{numTargets} syllables</strong>:
        </div>

        <div className="word-river">
          {letters.map((letter, i) => (
            <div key={i} className="letter-group">
              <div className="letter-stone">{letter}</div>
              {i < letters.length - 1 && (
                <button
                  className={`split-marker ${userSplits.includes(i + 1) ? 'active' : ''} ${
                    showResult ? (correctSplits.includes(i + 1) ? 'correct' : userSplits.includes(i + 1) ? 'wrong' : '') : ''
                  }`}
                  onClick={() => toggleSplit(i + 1)}
                  disabled={showResult}
                  aria-label={`Split at position ${i + 1}`}
                />
              )}
            </div>
          ))}
        </div>

        <div className="syllable-status">
          You've made <strong>{userSplits.length}</strong> split{userSplits.length !== 1 ? 's' : ''} ({numTargets - 1} needed)
        </div>

        {!showResult && (
          <button
            className="btn btn-primary"
            onClick={checkAnswer}
            disabled={userSplits.length === 0}
          >
            Check it! →
          </button>
        )}

        {showResult && (
          <div className={`result-banner ${resultGood ? 'result-good' : 'result-try'}`}>
            {resultGood
              ? `Perfect! ${item.syllables.join(' · ')} 🎉`
              : `The right way: ${item.syllables.join(' · ')}`}
          </div>
        )}
      </div>
    </div>
  );
}

// ===================== TREAT STOP =====================

function TreatStop({ onComplete }) {
  const [opened, setOpened] = useState(false);
  return (
    <div className="screen treat-screen">
      <div className="treat-content">
        <div className="treat-mila">
          <Mila size={180} mood={opened ? 'celebrating' : 'happy'} />
        </div>
        <h2 className="treat-title">Free Treat Stop! 🦴</h2>
        <p className="treat-subtitle">
          {opened ? 'Mila says ¡Gracias!' : 'You\'ve been working hard. Tap the box to give Mila a treat!'}
        </p>
        {!opened ? (
          <button className="treat-box" onClick={() => setOpened(true)}>
            🎁
          </button>
        ) : (
          <>
            <div className="treats-rain">
              {Array.from({ length: 12 }, (_, i) => (
                <div key={i} className="treat-falling" style={{ left: `${i * 8 + 5}%`, animationDelay: `${i * 0.1}s` }}>
                  🦴
                </div>
              ))}
            </div>
            <button className="btn btn-primary" onClick={() => onComplete(true)}>
              Keep walking →
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ===================== FINISH SCREEN =====================

function FinishScreen({ treats, onReplay }) {
  return (
    <div className="screen finish-screen">
      <div className="confetti">
        {Array.from({ length: 30 }, (_, i) => (
          <div
            key={i}
            className="confetti-piece"
            style={{
              left: `${Math.random() * 100}%`,
              background: ['#A28043', '#6B8E6B', '#B8724C', '#5B8BA0', '#C4A456'][i % 5],
              animationDelay: `${Math.random() * 1}s`,
              animationDuration: `${2 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>
      <div className="finish-content">
        <div className="finish-mila">
          <Mila size={240} mood="celebrating" items={['collar', 'bandana', 'backpack', 'hat', 'medal']} />
        </div>
        <h1 className="finish-title">¡Lo lograste! You did it!</h1>
        <p className="finish-subtitle">
          Mila made it all the way home. You earned <strong>{treats} treats</strong> on the walk!
        </p>
        <div className="finish-stats">
          <div className="finish-stat">
            <div className="finish-stat-num">{treats}</div>
            <div className="finish-stat-label">Treats earned</div>
          </div>
          <div className="finish-stat">
            <div className="finish-stat-num">{walkStops.length}</div>
            <div className="finish-stat-label">Stops completed</div>
          </div>
          <div className="finish-stat">
            <div className="finish-stat-num">🏆</div>
            <div className="finish-stat-label">Mila the Champion</div>
          </div>
        </div>
        <button className="btn btn-primary btn-large" onClick={onReplay}>
          Walk again 🐾
        </button>
      </div>
    </div>
  );
}

// ===================== APP ROOT =====================

const STORAGE_KEY = 'milas-adventure-progress';

export default function App() {
  const [view, setView] = useState('start'); // start | trail | challenge | finish
  const [currentStop, setCurrentStop] = useState(0);
  const [treats, setTreats] = useState(0);
  const [loadedFromStorage, setLoadedFromStorage] = useState(false);

  // Load saved progress
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const data = JSON.parse(saved);
        if (data.currentStop !== undefined && data.currentStop < walkStops.length) {
          setLoadedFromStorage(true);
        }
      }
    } catch {}
  }, []);

  // Save progress whenever it changes
  useEffect(() => {
    if (view !== 'start') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({ currentStop, treats }));
      } catch {}
    }
  }, [currentStop, treats, view]);

  const outfit = currentOutfit(currentStop);

  const handleStart = () => {
    setCurrentStop(0);
    setTreats(0);
    setView('trail');
    try { localStorage.removeItem(STORAGE_KEY); } catch {}
  };

  const handleContinue = () => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const data = JSON.parse(saved);
        setCurrentStop(data.currentStop || 0);
        setTreats(data.treats || 0);
      }
    } catch {}
    setView('trail');
  };

  const handleNextStop = () => {
    const stop = walkStops[currentStop];
    if (!stop) return;
    if (stop.mode === 'finish') {
      setView('finish');
    } else if (stop.mode === 'treat') {
      setView('treat');
    } else {
      setView('challenge');
    }
  };

  const handleChallengeComplete = (won) => {
    if (won) setTreats((t) => t + 1);
    setCurrentStop((s) => s + 1);
    setView('trail');
  };

  const handleSkip = () => {
    setView('trail');
  };

  const handleReplay = () => {
    setCurrentStop(0);
    setTreats(0);
    try { localStorage.removeItem(STORAGE_KEY); } catch {}
    setView('start');
  };

  // ----- Render -----
  if (view === 'start') {
    return <StartScreen onStart={handleStart} onContinue={handleContinue} hasProgress={loadedFromStorage} />;
  }

  if (view === 'finish') {
    return <FinishScreen treats={treats} onReplay={handleReplay} />;
  }

  if (view === 'treat') {
    return <TreatStop onComplete={() => { setCurrentStop((s) => s + 1); setView('trail'); }} />;
  }

  if (view === 'challenge') {
    const stop = walkStops[currentStop];
    if (stop?.mode === 'cloze') return <ClozeChallenge onComplete={handleChallengeComplete} onSkip={handleSkip} />;
    if (stop?.mode === 'cognate') return <CognateChallenge onComplete={handleChallengeComplete} onSkip={handleSkip} />;
    if (stop?.mode === 'syllable') return <SyllableChallenge onComplete={handleChallengeComplete} onSkip={handleSkip} />;
  }

  // Default: trail map
  return <TrailMap currentStop={currentStop} onContinue={handleNextStop} treats={treats} outfit={outfit} />;
}
